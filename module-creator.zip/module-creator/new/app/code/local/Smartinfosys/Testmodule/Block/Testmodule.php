<?php
class Smartinfosys_Testmodule_Block_Testmodule extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getTestmodule()     
     { 
        if (!$this->hasData('testmodule')) {
            $this->setData('testmodule', Mage::registry('testmodule'));
        }
        return $this->getData('testmodule');
        
    }
}