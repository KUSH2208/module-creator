<?php

class Smartinfosys_Testmodule_Block_Adminhtml_Testmodule_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'testmodule';
        $this->_controller = 'adminhtml_testmodule';
        
        $this->_updateButton('save', 'label', Mage::helper('testmodule')->__('Save Item'));
        $this->_updateButton('delete', 'label', Mage::helper('testmodule')->__('Delete Item'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('testmodule_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'testmodule_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'testmodule_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('testmodule_data') && Mage::registry('testmodule_data')->getId() ) {
            return Mage::helper('testmodule')->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('testmodule_data')->getTitle()));
        } else {
            return Mage::helper('testmodule')->__('Add Item');
        }
    }
}