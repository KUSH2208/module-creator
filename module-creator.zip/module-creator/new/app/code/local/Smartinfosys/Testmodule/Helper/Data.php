<?php

class Smartinfosys_Testmodule_Helper_Data extends Mage_Core_Helper_Abstract
{

}