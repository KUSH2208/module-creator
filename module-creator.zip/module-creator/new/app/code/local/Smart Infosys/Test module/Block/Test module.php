<?php
class Smart Infosys_Test module_Block_Test module extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getTest module()     
     { 
        if (!$this->hasData('test module')) {
            $this->setData('test module', Mage::registry('test module'));
        }
        return $this->getData('test module');
        
    }
}