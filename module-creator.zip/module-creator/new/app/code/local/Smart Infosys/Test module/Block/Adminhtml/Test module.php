<?php
class Smart Infosys_Test module_Block_Adminhtml_Test module extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_test module';
    $this->_blockGroup = 'test module';
    $this->_headerText = Mage::helper('test module')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('test module')->__('Add Item');
    parent::__construct();
  }
}