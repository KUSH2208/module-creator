<?php
class Smart Infosys_Test module_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/test module?id=15 
    	 *  or
    	 * http://site.com/test module/id/15 	
    	 */
    	/* 
		$test module_id = $this->getRequest()->getParam('id');

  		if($test module_id != null && $test module_id != '')	{
			$test module = Mage::getModel('test module/test module')->load($test module_id)->getData();
		} else {
			$test module = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($test module == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$test moduleTable = $resource->getTableName('test module');
			
			$select = $read->select()
			   ->from($test moduleTable,array('test module_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$test module = $read->fetchRow($select);
		}
		Mage::register('test module', $test module);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}