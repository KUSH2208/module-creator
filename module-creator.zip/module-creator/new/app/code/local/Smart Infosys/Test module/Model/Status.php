<?php

class Smart Infosys_Test module_Model_Status extends Varien_Object
{
    const STATUS_ENABLED	= 1;
    const STATUS_DISABLED	= 2;

    static public function getOptionArray()
    {
        return array(
            self::STATUS_ENABLED    => Mage::helper('test module')->__('Enabled'),
            self::STATUS_DISABLED   => Mage::helper('test module')->__('Disabled')
        );
    }
}