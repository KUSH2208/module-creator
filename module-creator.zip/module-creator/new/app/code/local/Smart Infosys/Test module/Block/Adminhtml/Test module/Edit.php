<?php

class Smart Infosys_Test module_Block_Adminhtml_Test module_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'test module';
        $this->_controller = 'adminhtml_test module';
        
        $this->_updateButton('save', 'label', Mage::helper('test module')->__('Save Item'));
        $this->_updateButton('delete', 'label', Mage::helper('test module')->__('Delete Item'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('test module_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'test module_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'test module_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('test module_data') && Mage::registry('test module_data')->getId() ) {
            return Mage::helper('test module')->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('test module_data')->getTitle()));
        } else {
            return Mage::helper('test module')->__('Add Item');
        }
    }
}