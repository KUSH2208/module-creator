<?php
class Secondskinaudio_NewsletterGiftSubsribe_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/newslettergiftsubsribe?id=15 
    	 *  or
    	 * http://site.com/newslettergiftsubsribe/id/15 	
    	 */
    	/* 
		$newslettergiftsubsribe_id = $this->getRequest()->getParam('id');

  		if($newslettergiftsubsribe_id != null && $newslettergiftsubsribe_id != '')	{
			$newslettergiftsubsribe = Mage::getModel('newslettergiftsubsribe/newslettergiftsubsribe')->load($newslettergiftsubsribe_id)->getData();
		} else {
			$newslettergiftsubsribe = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($newslettergiftsubsribe == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$newslettergiftsubsribeTable = $resource->getTableName('newslettergiftsubsribe');
			
			$select = $read->select()
			   ->from($newslettergiftsubsribeTable,array('newslettergiftsubsribe_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$newslettergiftsubsribe = $read->fetchRow($select);
		}
		Mage::register('newslettergiftsubsribe', $newslettergiftsubsribe);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}