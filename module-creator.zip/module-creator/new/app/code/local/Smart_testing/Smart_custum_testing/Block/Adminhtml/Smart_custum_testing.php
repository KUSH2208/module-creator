<?php
class Smart_testing_Smart_custum_testing_Block_Adminhtml_Smart_custum_testing extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_smart_custum_testing';
    $this->_blockGroup = 'smart_custum_testing';
    $this->_headerText = Mage::helper('smart_custum_testing')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('smart_custum_testing')->__('Add Item');
    parent::__construct();
  }
}