<?php
class Smart_testing_Smart_custum_testing_Block_Smart_custum_testing extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getSmart_custum_testing()     
     { 
        if (!$this->hasData('smart_custum_testing')) {
            $this->setData('smart_custum_testing', Mage::registry('smart_custum_testing'));
        }
        return $this->getData('smart_custum_testing');
        
    }
}