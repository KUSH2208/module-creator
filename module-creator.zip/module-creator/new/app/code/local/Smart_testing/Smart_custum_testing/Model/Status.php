<?php

class Smart_testing_Smart_custum_testing_Model_Status extends Varien_Object
{
    const STATUS_ENABLED	= 1;
    const STATUS_DISABLED	= 2;

    static public function getOptionArray()
    {
        return array(
            self::STATUS_ENABLED    => Mage::helper('smart_custum_testing')->__('Enabled'),
            self::STATUS_DISABLED   => Mage::helper('smart_custum_testing')->__('Disabled')
        );
    }
}