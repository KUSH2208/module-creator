<?php

class Smart_testing_Smart_custum_testing_Model_Mysql4_Smart_custum_testing_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('smart_custum_testing/smart_custum_testing');
    }
}