<?php

class Smart_testing_Smart_custum_testing_Block_Adminhtml_Smart_custum_testing_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  public function __construct()
  {
      parent::__construct();
      $this->setId('smart_custum_testing_tabs');
      $this->setDestElementId('edit_form');
      $this->setTitle(Mage::helper('smart_custum_testing')->__('Item Information'));
  }

  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
          'label'     => Mage::helper('smart_custum_testing')->__('Item Information'),
          'title'     => Mage::helper('smart_custum_testing')->__('Item Information'),
          'content'   => $this->getLayout()->createBlock('smart_custum_testing/adminhtml_smart_custum_testing_edit_tab_form')->toHtml(),
      ));
     
      return parent::_beforeToHtml();
  }
}