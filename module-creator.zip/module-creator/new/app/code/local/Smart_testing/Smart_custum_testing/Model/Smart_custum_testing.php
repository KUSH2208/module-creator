<?php

class Smart_testing_Smart_custum_testing_Model_Smart_custum_testing extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('smart_custum_testing/smart_custum_testing');
    }
}