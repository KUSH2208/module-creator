<?php

class Smart_testing_Smart_custum_testing_Block_Adminhtml_Smart_custum_testing_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
      parent::__construct();
      $this->setId('smart_custum_testingGrid');
      $this->setDefaultSort('smart_custum_testing_id');
      $this->setDefaultDir('ASC');
      $this->setSaveParametersInSession(true);
  }

  protected function _prepareCollection()
  {
      $collection = Mage::getModel('smart_custum_testing/smart_custum_testing')->getCollection();
      $this->setCollection($collection);
      return parent::_prepareCollection();
  }

  protected function _prepareColumns()
  {
      $this->addColumn('smart_custum_testing_id', array(
          'header'    => Mage::helper('smart_custum_testing')->__('ID'),
          'align'     =>'right',
          'width'     => '50px',
          'index'     => 'smart_custum_testing_id',
      ));

      $this->addColumn('title', array(
          'header'    => Mage::helper('smart_custum_testing')->__('Title'),
          'align'     =>'left',
          'index'     => 'title',
      ));

	  /*
      $this->addColumn('content', array(
			'header'    => Mage::helper('smart_custum_testing')->__('Item Content'),
			'width'     => '150px',
			'index'     => 'content',
      ));
	  */

      $this->addColumn('status', array(
          'header'    => Mage::helper('smart_custum_testing')->__('Status'),
          'align'     => 'left',
          'width'     => '80px',
          'index'     => 'status',
          'type'      => 'options',
          'options'   => array(
              1 => 'Enabled',
              2 => 'Disabled',
          ),
      ));
	  
        $this->addColumn('action',
            array(
                'header'    =>  Mage::helper('smart_custum_testing')->__('Action'),
                'width'     => '100',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => Mage::helper('smart_custum_testing')->__('Edit'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        ));
		
		$this->addExportType('*/*/exportCsv', Mage::helper('smart_custum_testing')->__('CSV'));
		$this->addExportType('*/*/exportXml', Mage::helper('smart_custum_testing')->__('XML'));
	  
      return parent::_prepareColumns();
  }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('smart_custum_testing_id');
        $this->getMassactionBlock()->setFormFieldName('smart_custum_testing');

        $this->getMassactionBlock()->addItem('delete', array(
             'label'    => Mage::helper('smart_custum_testing')->__('Delete'),
             'url'      => $this->getUrl('*/*/massDelete'),
             'confirm'  => Mage::helper('smart_custum_testing')->__('Are you sure?')
        ));

        $statuses = Mage::getSingleton('smart_custum_testing/status')->getOptionArray();

        array_unshift($statuses, array('label'=>'', 'value'=>''));
        $this->getMassactionBlock()->addItem('status', array(
             'label'=> Mage::helper('smart_custum_testing')->__('Change status'),
             'url'  => $this->getUrl('*/*/massStatus', array('_current'=>true)),
             'additional' => array(
                    'visibility' => array(
                         'name' => 'status',
                         'type' => 'select',
                         'class' => 'required-entry',
                         'label' => Mage::helper('smart_custum_testing')->__('Status'),
                         'values' => $statuses
                     )
             )
        ));
        return $this;
    }

  public function getRowUrl($row)
  {
      return $this->getUrl('*/*/edit', array('id' => $row->getId()));
  }

}