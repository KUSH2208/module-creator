<?php

class Smart_testing_Smart_custum_testing_Model_Mysql4_Smart_custum_testing extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the smart_custum_testing_id refers to the key field in your database table.
        $this->_init('smart_custum_testing/smart_custum_testing', 'smart_custum_testing_id');
    }
}