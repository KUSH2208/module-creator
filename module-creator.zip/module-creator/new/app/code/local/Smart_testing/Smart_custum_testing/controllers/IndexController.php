<?php
class Smart_testing_Smart_custum_testing_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/smart_custum_testing?id=15 
    	 *  or
    	 * http://site.com/smart_custum_testing/id/15 	
    	 */
    	/* 
		$smart_custum_testing_id = $this->getRequest()->getParam('id');

  		if($smart_custum_testing_id != null && $smart_custum_testing_id != '')	{
			$smart_custum_testing = Mage::getModel('smart_custum_testing/smart_custum_testing')->load($smart_custum_testing_id)->getData();
		} else {
			$smart_custum_testing = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($smart_custum_testing == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$smart_custum_testingTable = $resource->getTableName('smart_custum_testing');
			
			$select = $read->select()
			   ->from($smart_custum_testingTable,array('smart_custum_testing_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$smart_custum_testing = $read->fetchRow($select);
		}
		Mage::register('smart_custum_testing', $smart_custum_testing);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}