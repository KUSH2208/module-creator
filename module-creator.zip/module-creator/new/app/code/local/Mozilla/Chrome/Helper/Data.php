<?php

class Mozilla_Chrome_Helper_Data extends Mage_Core_Helper_Abstract
{

}