<?php
class Mozilla_Chrome_Block_Adminhtml_Chrome extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_chrome';
    $this->_blockGroup = 'chrome';
    $this->_headerText = Mage::helper('chrome')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('chrome')->__('Add Item');
    parent::__construct();
  }
}