<?php
class Mozilla_Chrome_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/chrome?id=15 
    	 *  or
    	 * http://site.com/chrome/id/15 	
    	 */
    	/* 
		$chrome_id = $this->getRequest()->getParam('id');

  		if($chrome_id != null && $chrome_id != '')	{
			$chrome = Mage::getModel('chrome/chrome')->load($chrome_id)->getData();
		} else {
			$chrome = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($chrome == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$chromeTable = $resource->getTableName('chrome');
			
			$select = $read->select()
			   ->from($chromeTable,array('chrome_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$chrome = $read->fetchRow($select);
		}
		Mage::register('chrome', $chrome);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}