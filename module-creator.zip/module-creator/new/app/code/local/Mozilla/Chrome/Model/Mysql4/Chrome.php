<?php

class Mozilla_Chrome_Model_Mysql4_Chrome extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the chrome_id refers to the key field in your database table.
        $this->_init('chrome/chrome', 'chrome_id');
    }
}