<?php
class Mozilla_Chrome_Block_Chrome extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getChrome()     
     { 
        if (!$this->hasData('chrome')) {
            $this->setData('chrome', Mage::registry('chrome'));
        }
        return $this->getData('chrome');
        
    }
}