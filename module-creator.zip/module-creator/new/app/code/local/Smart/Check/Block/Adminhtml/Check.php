<?php
class Smart_Check_Block_Adminhtml_Check extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_check';
    $this->_blockGroup = 'check';
    $this->_headerText = Mage::helper('check')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('check')->__('Add Item');
    parent::__construct();
  }
}