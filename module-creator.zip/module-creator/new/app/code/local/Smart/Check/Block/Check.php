<?php
class Smart_Check_Block_Check extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getCheck()     
     { 
        if (!$this->hasData('check')) {
            $this->setData('check', Mage::registry('check'));
        }
        return $this->getData('check');
        
    }
}