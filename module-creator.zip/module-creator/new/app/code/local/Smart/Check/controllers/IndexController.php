<?php
class Smart_Check_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/check?id=15 
    	 *  or
    	 * http://site.com/check/id/15 	
    	 */
    	/* 
		$check_id = $this->getRequest()->getParam('id');

  		if($check_id != null && $check_id != '')	{
			$check = Mage::getModel('check/check')->load($check_id)->getData();
		} else {
			$check = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($check == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$checkTable = $resource->getTableName('check');
			
			$select = $read->select()
			   ->from($checkTable,array('check_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$check = $read->fetchRow($select);
		}
		Mage::register('check', $check);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}