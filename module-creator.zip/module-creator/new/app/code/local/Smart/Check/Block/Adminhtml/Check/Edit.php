<?php

class Smart_Check_Block_Adminhtml_Check_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'check';
        $this->_controller = 'adminhtml_check';
        
        $this->_updateButton('save', 'label', Mage::helper('check')->__('Save Item'));
        $this->_updateButton('delete', 'label', Mage::helper('check')->__('Delete Item'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('check_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'check_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'check_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('check_data') && Mage::registry('check_data')->getId() ) {
            return Mage::helper('check')->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('check_data')->getTitle()));
        } else {
            return Mage::helper('check')->__('Add Item');
        }
    }
}