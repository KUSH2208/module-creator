<?php
class Smart_Smart_Block_Smart extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getSmart()     
     { 
        if (!$this->hasData('smart')) {
            $this->setData('smart', Mage::registry('smart'));
        }
        return $this->getData('smart');
        
    }
}