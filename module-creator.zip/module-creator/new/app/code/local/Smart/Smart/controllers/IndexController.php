<?php
class Smart_Smart_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/smart?id=15 
    	 *  or
    	 * http://site.com/smart/id/15 	
    	 */
    	/* 
		$smart_id = $this->getRequest()->getParam('id');

  		if($smart_id != null && $smart_id != '')	{
			$smart = Mage::getModel('smart/smart')->load($smart_id)->getData();
		} else {
			$smart = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($smart == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$smartTable = $resource->getTableName('smart');
			
			$select = $read->select()
			   ->from($smartTable,array('smart_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$smart = $read->fetchRow($select);
		}
		Mage::register('smart', $smart);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}