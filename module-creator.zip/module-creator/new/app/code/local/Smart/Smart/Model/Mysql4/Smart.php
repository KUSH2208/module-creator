<?php

class Smart_Smart_Model_Mysql4_Smart extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the smart_id refers to the key field in your database table.
        $this->_init('smart/smart', 'smart_id');
    }
}