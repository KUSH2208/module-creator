<?php
class Smart_Smart_Block_Adminhtml_Smart extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_smart';
    $this->_blockGroup = 'smart';
    $this->_headerText = Mage::helper('smart')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('smart')->__('Add Item');
    parent::__construct();
  }
}