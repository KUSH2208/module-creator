<?php
class Smart_Woodfordescheckout_Block_Adminhtml_Woodfordescheckout extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_woodfordescheckout';
    $this->_blockGroup = 'woodfordescheckout';
    $this->_headerText = Mage::helper('woodfordescheckout')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('woodfordescheckout')->__('Add Item');
    parent::__construct();
  }
}