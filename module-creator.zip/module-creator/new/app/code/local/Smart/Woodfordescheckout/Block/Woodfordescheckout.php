<?php
class Smart_Woodfordescheckout_Block_Woodfordescheckout extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getWoodfordescheckout()     
     { 
        if (!$this->hasData('woodfordescheckout')) {
            $this->setData('woodfordescheckout', Mage::registry('woodfordescheckout'));
        }
        return $this->getData('woodfordescheckout');
        
    }
}