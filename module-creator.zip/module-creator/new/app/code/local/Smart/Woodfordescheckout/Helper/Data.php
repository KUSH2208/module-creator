<?php

class Smart_Woodfordescheckout_Helper_Data extends Mage_Core_Helper_Abstract
{

}