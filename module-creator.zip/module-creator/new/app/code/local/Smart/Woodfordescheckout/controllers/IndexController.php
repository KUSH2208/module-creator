<?php
class Smart_Woodfordescheckout_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/woodfordescheckout?id=15 
    	 *  or
    	 * http://site.com/woodfordescheckout/id/15 	
    	 */
    	/* 
		$woodfordescheckout_id = $this->getRequest()->getParam('id');

  		if($woodfordescheckout_id != null && $woodfordescheckout_id != '')	{
			$woodfordescheckout = Mage::getModel('woodfordescheckout/woodfordescheckout')->load($woodfordescheckout_id)->getData();
		} else {
			$woodfordescheckout = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($woodfordescheckout == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$woodfordescheckoutTable = $resource->getTableName('woodfordescheckout');
			
			$select = $read->select()
			   ->from($woodfordescheckoutTable,array('woodfordescheckout_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$woodfordescheckout = $read->fetchRow($select);
		}
		Mage::register('woodfordescheckout', $woodfordescheckout);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}