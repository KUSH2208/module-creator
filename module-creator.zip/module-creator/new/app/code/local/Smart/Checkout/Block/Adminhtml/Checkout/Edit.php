<?php

class Smart_Checkout_Block_Adminhtml_Checkout_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'checkout';
        $this->_controller = 'adminhtml_checkout';
        
        $this->_updateButton('save', 'label', Mage::helper('checkout')->__('Save Item'));
        $this->_updateButton('delete', 'label', Mage::helper('checkout')->__('Delete Item'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('checkout_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'checkout_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'checkout_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('checkout_data') && Mage::registry('checkout_data')->getId() ) {
            return Mage::helper('checkout')->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('checkout_data')->getTitle()));
        } else {
            return Mage::helper('checkout')->__('Add Item');
        }
    }
}