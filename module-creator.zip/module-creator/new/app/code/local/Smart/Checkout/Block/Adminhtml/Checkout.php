<?php
class Smart_Checkout_Block_Adminhtml_Checkout extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_checkout';
    $this->_blockGroup = 'checkout';
    $this->_headerText = Mage::helper('checkout')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('checkout')->__('Add Item');
    parent::__construct();
  }
}