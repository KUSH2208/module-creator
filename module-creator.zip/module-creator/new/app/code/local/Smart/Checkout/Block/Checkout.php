<?php
class Smart_Checkout_Block_Checkout extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getCheckout()     
     { 
        if (!$this->hasData('checkout')) {
            $this->setData('checkout', Mage::registry('checkout'));
        }
        return $this->getData('checkout');
        
    }
}