<?php

class Smart_Checkout_Model_Checkout extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('checkout/checkout');
    }
}