<?php
class Smart_Checkout_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/checkout?id=15 
    	 *  or
    	 * http://site.com/checkout/id/15 	
    	 */
    	/* 
		$checkout_id = $this->getRequest()->getParam('id');

  		if($checkout_id != null && $checkout_id != '')	{
			$checkout = Mage::getModel('checkout/checkout')->load($checkout_id)->getData();
		} else {
			$checkout = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($checkout == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$checkoutTable = $resource->getTableName('checkout');
			
			$select = $read->select()
			   ->from($checkoutTable,array('checkout_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$checkout = $read->fetchRow($select);
		}
		Mage::register('checkout', $checkout);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}