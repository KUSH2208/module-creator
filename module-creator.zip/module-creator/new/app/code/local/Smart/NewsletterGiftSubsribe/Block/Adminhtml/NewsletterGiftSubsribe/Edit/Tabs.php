<?php

class Smart_NewsletterGiftSubsribe_Block_Adminhtml_NewsletterGiftSubsribe_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  public function __construct()
  {
      parent::__construct();
      $this->setId('newslettergiftsubsribe_tabs');
      $this->setDestElementId('edit_form');
      $this->setTitle(Mage::helper('newslettergiftsubsribe')->__('Item Information'));
  }

  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
          'label'     => Mage::helper('newslettergiftsubsribe')->__('Item Information'),
          'title'     => Mage::helper('newslettergiftsubsribe')->__('Item Information'),
          'content'   => $this->getLayout()->createBlock('newslettergiftsubsribe/adminhtml_newslettergiftsubsribe_edit_tab_form')->toHtml(),
      ));
     
      return parent::_beforeToHtml();
  }
}