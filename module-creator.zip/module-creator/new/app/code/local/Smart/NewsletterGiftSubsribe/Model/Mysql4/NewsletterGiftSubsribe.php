<?php

class Smart_NewsletterGiftSubsribe_Model_Mysql4_NewsletterGiftSubsribe extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the newslettergiftsubsribe_id refers to the key field in your database table.
        $this->_init('newslettergiftsubsribe/newslettergiftsubsribe', 'newslettergiftsubsribe_id');
    }
}