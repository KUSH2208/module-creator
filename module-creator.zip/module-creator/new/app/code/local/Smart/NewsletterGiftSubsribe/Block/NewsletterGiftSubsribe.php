<?php
class Smart_NewsletterGiftSubsribe_Block_NewsletterGiftSubsribe extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getNewsletterGiftSubsribe()     
     { 
        if (!$this->hasData('newslettergiftsubsribe')) {
            $this->setData('newslettergiftsubsribe', Mage::registry('newslettergiftsubsribe'));
        }
        return $this->getData('newslettergiftsubsribe');
        
    }
}