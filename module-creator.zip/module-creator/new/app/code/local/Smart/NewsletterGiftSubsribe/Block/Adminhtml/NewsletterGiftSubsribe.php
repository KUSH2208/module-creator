<?php
class Smart_NewsletterGiftSubsribe_Block_Adminhtml_NewsletterGiftSubsribe extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_newslettergiftsubsribe';
    $this->_blockGroup = 'newslettergiftsubsribe';
    $this->_headerText = Mage::helper('newslettergiftsubsribe')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('newslettergiftsubsribe')->__('Add Item');
    parent::__construct();
  }
}