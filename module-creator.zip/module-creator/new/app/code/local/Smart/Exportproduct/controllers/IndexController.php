<?php
class Smart_Exportproduct_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/exportproduct?id=15 
    	 *  or
    	 * http://site.com/exportproduct/id/15 	
    	 */
    	/* 
		$exportproduct_id = $this->getRequest()->getParam('id');

  		if($exportproduct_id != null && $exportproduct_id != '')	{
			$exportproduct = Mage::getModel('exportproduct/exportproduct')->load($exportproduct_id)->getData();
		} else {
			$exportproduct = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($exportproduct == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$exportproductTable = $resource->getTableName('exportproduct');
			
			$select = $read->select()
			   ->from($exportproductTable,array('exportproduct_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$exportproduct = $read->fetchRow($select);
		}
		Mage::register('exportproduct', $exportproduct);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}