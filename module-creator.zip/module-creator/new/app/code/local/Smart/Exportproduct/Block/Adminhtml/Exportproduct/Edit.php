<?php

class Smart_Exportproduct_Block_Adminhtml_Exportproduct_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'exportproduct';
        $this->_controller = 'adminhtml_exportproduct';
        
        $this->_updateButton('save', 'label', Mage::helper('exportproduct')->__('Save Item'));
        $this->_updateButton('delete', 'label', Mage::helper('exportproduct')->__('Delete Item'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('exportproduct_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'exportproduct_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'exportproduct_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('exportproduct_data') && Mage::registry('exportproduct_data')->getId() ) {
            return Mage::helper('exportproduct')->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('exportproduct_data')->getTitle()));
        } else {
            return Mage::helper('exportproduct')->__('Add Item');
        }
    }
}