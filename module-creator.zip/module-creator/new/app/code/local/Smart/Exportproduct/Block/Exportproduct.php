<?php
class Smart_Exportproduct_Block_Exportproduct extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getExportproduct()     
     { 
        if (!$this->hasData('exportproduct')) {
            $this->setData('exportproduct', Mage::registry('exportproduct'));
        }
        return $this->getData('exportproduct');
        
    }
}